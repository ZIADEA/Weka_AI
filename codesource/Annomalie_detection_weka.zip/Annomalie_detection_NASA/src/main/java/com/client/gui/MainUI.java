package com.client.gui;

import com.detector.model.*;
import com.detector.utils.ModelUtils;
import com.detector.Report.PdfReportGenerator;
import weka.clusterers.SimpleKMeans;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.PrincipalComponents;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.util.*;

public class MainUI extends JFrame {
    private static final long serialVersionUID = 1L;

    private JTextField kField;
    private JTextField fileField;
    private JTextArea resultArea;
    private JCheckBox reuseModelCheckBox;
    private JTable clusterTable;
    private JTable confusionTable;
    private JPanel plotPanel;
    private File selectedFile;
    private Instances loadedData;
    private SimpleKMeans trainedModel;
    private JButton downloadReportBtn;

    public MainUI() {
        setTitle("Interface Clustering KMeans - Projet IA");
        setSize(1100, 850);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(4, 1));

        JPanel filePanel = new JPanel();
        fileField = new JTextField(40);
        fileField.setEditable(false);
        JButton chooseFileBtn = new JButton("Choisir fichier .arff");
        chooseFileBtn.addActionListener(e -> chooseFile());
        filePanel.add(new JLabel("Fichier : "));
        filePanel.add(fileField);
        filePanel.add(chooseFileBtn);

        JPanel kPanel = new JPanel();
        kPanel.add(new JLabel("Nombre de clusters (laisser vide pour auto) : "));
        kField = new JTextField(5);
        kPanel.add(kField);

        JPanel optionsPanel = new JPanel();
        reuseModelCheckBox = new JCheckBox("Réutiliser modèle préentraîné si disponible");
        optionsPanel.add(reuseModelCheckBox);

        JPanel actionPanel = new JPanel();
        JButton runBtn = new JButton("Lancer Clustering");
        JButton predictBtn = new JButton("Prédire Tuple");
        runBtn.addActionListener(e -> runClustering());
        predictBtn.addActionListener(e -> predictTuple());
        actionPanel.add(runBtn);
        actionPanel.add(predictBtn);

        inputPanel.add(filePanel);
        inputPanel.add(kPanel);
        inputPanel.add(optionsPanel);
        inputPanel.add(actionPanel);
        add(inputPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(1, 2));

        clusterTable = new JTable();
        JScrollPane tableScroll = new JScrollPane(clusterTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Clusters (avec détection d'anomalies)"));

        confusionTable = new JTable();
        JScrollPane confusionScroll = new JScrollPane(confusionTable);
        confusionScroll.setBorder(BorderFactory.createTitledBorder("Matrice de confusion"));

        JPanel tablesPanel = new JPanel(new GridLayout(2, 1));
        tablesPanel.add(tableScroll);
        tablesPanel.add(confusionScroll);

        plotPanel = new JPanel() {
            /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (loadedData != null && trainedModel != null) {
                    try {
                        Instances projected = applyPCA(loadedData);
                        int[] assignments = trainedModel.getAssignments();
                        int w = getWidth(), h = getHeight();
                        g.setColor(Color.LIGHT_GRAY);
                        g.drawRect(20, 20, w - 40, h - 40);
                        for (int i = 0; i < projected.numInstances(); i++) {
                            Instance inst = projected.instance(i);
                            int x = (int) ((inst.value(0) + 1) / 2 * (w - 40)) + 20;
                            int y = (int) ((1 - inst.value(1)) / 2 * (h - 40)) + 20;
                            g.setColor(getColor(assignments[i]));
                            g.fillOval(x, y, 6, 6);
                        }
                    } catch (Exception ignored) {}
                }
            }
        };
        plotPanel.setBorder(BorderFactory.createTitledBorder("Projection 2D (PCA)"));

        centerPanel.add(tablesPanel);
        centerPanel.add(plotPanel);
        add(centerPanel, BorderLayout.CENTER);

        resultArea = new JTextArea(6, 100);
        resultArea.setEditable(false);
        JScrollPane logScroll = new JScrollPane(resultArea);

        downloadReportBtn = new JButton("📄 Télécharger le rapport PDF");
        downloadReportBtn.setBackground(new Color(230, 230, 250)); // Lavande
        downloadReportBtn.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        downloadReportBtn.addActionListener(e -> {
            try {
                Desktop.getDesktop().open(new File("rapport_kmeans_final.pdf"));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Erreur lors de l'ouverture du PDF : " + ex.getMessage());
            }
        });

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(logScroll, BorderLayout.CENTER);
        southPanel.add(downloadReportBtn, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);
    }

    private void chooseFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("ARFF files", "arff"));
        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            selectedFile = chooser.getSelectedFile();
            fileField.setText(selectedFile.getAbsolutePath());
        }
    }

    private void runClustering() {
        try {
            if (selectedFile == null) {
                JOptionPane.showMessageDialog(null, "Veuillez choisir un fichier .arff");
                return;
            }
            Instances data = new DataSource(selectedFile.getAbsolutePath()).getDataSet();
            data = DatasetNormalizer.normalize(data);
            loadedData = data;

            int userK = -1;
            try { userK = Integer.parseInt(kField.getText()); } catch (Exception ignored) {}

            File modelFile = new File("src/main/resources/saved_models/kmeans.model");
            if (reuseModelCheckBox.isSelected() && modelFile.exists()) {
                trainedModel = (SimpleKMeans) ModelUtils.loadModel(modelFile.getPath());
                resultArea.setText("📦 Modèle chargé depuis le fichier.\n");
            } else {
                if (userK >= 2) {
                    trainedModel = new SimpleKMeans();
                    trainedModel.setNumClusters(userK);
                    trainedModel.setPreserveInstancesOrder(true);
                    trainedModel.buildClusterer(data);
                } else {
                    trainedModel = KMeansTuner.findBestKMeans(data, 2, 8);
                }
                ModelUtils.saveModel(trainedModel, modelFile.getPath());
                resultArea.setText("🧠 Nouveau modèle entraîné.\n");
            }

            int[] assignments = trainedModel.getAssignments();
            double sil = ClusterModelEvaluator.silhouetteScore(trainedModel, data);
            double comp = ClusterModelEvaluator.compactnessScore(trainedModel, data);
            int minSize = getMinClusterSize(assignments, trainedModel.getNumClusters());
            int k = trainedModel.getNumClusters();
            int anomalyCluster = getSmallestClusterIndex(assignments, k);

            resultArea.append("✔️ Nombre de clusters = " + k + ", Silhouette = " + String.format("%.4f", sil) +
                              ", Compacité = " + String.format("%.4f", comp) +
                              ", Taille cluster min = " + minSize +
                              ", Cluster considéré comme anomalie = C" + anomalyCluster + "\n");

            PdfReportGenerator.generateReport(
                "rapport_kmeans_final.pdf",
                selectedFile.getName(),
                0.0, 0.0, 0,
                new ArrayList<>(),
                sil, comp, data.numInstances(), minSize);

            updateClusterTable(assignments, anomalyCluster);
            updateConfusionMatrix(data, assignments);
            plotPanel.repaint();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erreur : " + e.getMessage());
        }
    }

    private void predictTuple() {
        if (trainedModel == null || loadedData == null) {
            JOptionPane.showMessageDialog(null, "Entraînez ou chargez un modèle d'abord.");
            return;
        }
        String input = JOptionPane.showInputDialog("Entrez un tuple (1.2,3.4,...) :");
        if (input == null || input.trim().isEmpty()) return;
        try {
            String[] parts = input.trim().split(",");
            double[] values = new double[parts.length];
            for (int i = 0; i < parts.length; i++) values[i] = Double.parseDouble(parts[i]);
            Instance inst = new weka.core.DenseInstance(1.0, values);
            inst.setDataset(loadedData);
            int cluster = trainedModel.clusterInstance(inst);
            JOptionPane.showMessageDialog(null, "→ Ce tuple est affecté au cluster : " + cluster);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erreur : " + e.getMessage());
        }
    }

    private void updateClusterTable(int[] assignments, int anomalyCluster) {
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Instance", "Cluster", "Anomalie ?"}, 0);
        for (int i = 0; i < assignments.length; i++) {
            boolean isAnomaly = assignments[i] == anomalyCluster;
            model.addRow(new Object[]{i, assignments[i], isAnomaly ? "⚠️ Oui" : "Non"});
        }
        clusterTable.setModel(model);
    }

    private void updateConfusionMatrix(Instances data, int[] assignments) {
        if (data.classIndex() == -1 && data.attribute("class") != null)
            data.setClass(data.attribute("class"));
        else if (data.classIndex() == -1 && data.attribute(data.numAttributes() - 1).isNominal())
            data.setClassIndex(data.numAttributes() - 1);
        else
            return;

        Map<String, Map<Integer, Integer>> matrix = new TreeMap<>();
        for (int i = 0; i < data.numInstances(); i++) {
            String label = data.instance(i).stringValue(data.classIndex());
            int cluster = assignments[i];
            matrix.putIfAbsent(label, new TreeMap<>());
            matrix.get(label).put(cluster, matrix.get(label).getOrDefault(cluster, 0) + 1);
        }

        Set<Integer> allClusters = new TreeSet<>();
        matrix.values().forEach(m -> allClusters.addAll(m.keySet()));

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Classe / Cluster");
        allClusters.forEach(c -> model.addColumn("C" + c));

        for (String label : matrix.keySet()) {
            Vector<Object> row = new Vector<>();
            row.add(label);
            for (int c : allClusters) {
                row.add(matrix.get(label).getOrDefault(c, 0));
            }
            model.addRow(row);
        }

        confusionTable.setModel(model);
    }

    private int getMinClusterSize(int[] a, int k) {
        int[] s = new int[k]; for (int i : a) s[i]++;
        return Arrays.stream(s).min().orElse(0);
    }

    private int getSmallestClusterIndex(int[] a, int k) {
        int[] sizes = new int[k]; for (int i : a) sizes[i]++;
        int minIdx = 0;
        for (int i = 1; i < k; i++) {
            if (sizes[i] < sizes[minIdx]) minIdx = i;
        }
        return minIdx;
    }

    private Instances applyPCA(Instances data) throws Exception {
        PrincipalComponents pca = new PrincipalComponents();
        pca.setMaximumAttributes(2);
        pca.setInputFormat(data);
        return Filter.useFilter(data, pca);
    }

    private Color getColor(int id) {
        Color[] palette = {Color.RED, Color.BLUE, Color.GREEN, Color.ORANGE, Color.MAGENTA, Color.CYAN, Color.PINK};
        return palette[id % palette.length];
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainUI().setVisible(true));
    }
}
