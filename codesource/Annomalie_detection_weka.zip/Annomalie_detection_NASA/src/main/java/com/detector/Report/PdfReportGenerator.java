package com.detector.Report;

import java.io.FileOutputStream;
import java.util.List;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public class PdfReportGenerator {
    public static void generateReport(String fileName, String datasetName,
                                      double dbscanSilhouette, double dbscanCompactness, int nbAnomalies, List<String> anomalies,
                                      double kmeansSilhouette, double kmeansCompactness,
                                      int totalInstances, int minClusterSize) throws Exception {

        Document doc = new Document(PageSize.A4);
        PdfWriter.getInstance(doc, new FileOutputStream(fileName));
        doc.open();

        Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);
        Font sectionFont = new Font(Font.HELVETICA, 14, Font.BOLD);
        Font textFont = new Font(Font.HELVETICA, 12);

        doc.add(new Paragraph("Rapport de Clustering KMeans", titleFont));
        doc.add(new Paragraph("\nDataset : " + datasetName, textFont));
        doc.add(new Paragraph("Nombre total d'instances : " + totalInstances, textFont));
        doc.add(new Paragraph("\n"));

        doc.add(new Paragraph("Évaluation du modèle KMeans", sectionFont));
        doc.add(new Paragraph("Score de silhouette : " + String.format("%.4f", kmeansSilhouette), textFont));
        doc.add(new Paragraph("Score de compacité : " + String.format("%.4f", kmeansCompactness), textFont));
        doc.add(new Paragraph("Taille minimale d’un cluster : " + minClusterSize, textFont));

        doc.close();
    }
}
