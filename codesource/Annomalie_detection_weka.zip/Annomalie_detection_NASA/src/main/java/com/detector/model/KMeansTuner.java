package com.detector.model;

import weka.clusterers.SimpleKMeans;
import weka.core.Instances;

public class KMeansTuner {

    /**
     * Teste plusieurs valeurs de k pour trouver le meilleur modèle KMeans selon le score de silhouette.
     * @param data Les données à clusteriser
     * @param minK Valeur minimale de k (ex. 2)
     * @param maxK Valeur maximale de k (ex. 8)
     * @return Le meilleur modèle entraîné
     * @throws Exception si aucun modèle valide n’est trouvé
     */
    public static SimpleKMeans findBestKMeans(Instances data, int minK, int maxK) throws Exception {
        double bestSilhouette = Double.NEGATIVE_INFINITY;
        SimpleKMeans bestModel = null;

        for (int k = minK; k <= maxK; k++) {
            try {
                SimpleKMeans model = new SimpleKMeans();
                model.setNumClusters(k);
                model.setPreserveInstancesOrder(true);
                model.buildClusterer(data);

                double silhouette = ClusterModelEvaluator.silhouetteScore(model, data);
                System.out.println("k = " + k + " → silhouette = " + String.format("%.4f", silhouette));

                if (silhouette > bestSilhouette) {
                    bestSilhouette = silhouette;
                    bestModel = model;
                }
            } catch (Exception e) {
                System.out.println("⚠️ Échec pour k = " + k + " → " + e.getMessage());
            }
        }

        if (bestModel == null) {
            throw new Exception("❌ Aucun modèle KMeans valide trouvé entre k = " + minK + " et " + maxK);
        }

        return bestModel;
    }
}
