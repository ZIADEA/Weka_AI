package com.detector.model;

import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

import java.util.Map;

public class AnomalyDetector {
    public static void main(String[] args) {
        try {
            // Charger les données
            DataSource source = new DataSource("src/main/resources/bearing_data1.arff");
            Instances data = source.getDataSet();

            int kMin = 2;
            int kMax = 8;

            // Évaluer avec les 3 méthodes
            Map<Integer, Double> sseScores = WekaElbowEvaluator.evaluateSSE(data, kMin, kMax);
            Map<Integer, Double> silhouetteScores = SilhouetteScoreEvaluator.evaluateSilhouette(data, kMin, kMax);
            Map<Integer, int[]> clusterBalances = ClusterBalanceEvaluator.evaluateBalance(data, kMin, kMax);

            // Trouver le meilleur K
            int bestK = BestClusterAnalyzer.recommendBestK(sseScores, silhouetteScores, clusterBalances);
            System.out.println("\n>>> Nombre de clusters optimal trouvé : K = " + bestK);

            // Appliquer KMeans avec le meilleur K
            SimpleKMeans finalModel = new SimpleKMeans();
            finalModel.setNumClusters(bestK);
            finalModel.setPreserveInstancesOrder(true);
            finalModel.buildClusterer(data);
            int[] assignments = finalModel.getAssignments();

            // Identifier le plus petit cluster = anomalies
            int[] clusterCounts = new int[bestK];
            for (int cluster : assignments) clusterCounts[cluster]++;
            int minCluster = 0;
            for (int i = 1; i < bestK; i++) {
                if (clusterCounts[i] < clusterCounts[minCluster]) {
                    minCluster = i;
                }
            }

            System.out.println("\n>>> Anomalies détectées (cluster minoritaire : " + minCluster + ") :");
            for (int i = 0; i < assignments.length; i++) {
                if (assignments[i] == minCluster) {
                    System.out.println("⚠️  Instance " + i + " est potentiellement une anomalie.");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
