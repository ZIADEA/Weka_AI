package com.detector.Report;

import com.detector.model.ClusterModelEvaluator;
import com.detector.model.DatasetNormalizer;
import com.detector.model.KMeansTuner;
import com.detector.utils.ModelUtils;
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

import java.util.List;

public class MainReportGenerator {
    public static void main(String[] args) {
        try {
            // === Chargement et normalisation des données ===
            String datasetPath = "src/main/resources/r15.arff";
            Instances data = new DataSource(datasetPath).getDataSet();
            data = DatasetNormalizer.normalize(data);
            String datasetName = "r15.arff";

            // === Choix utilisateur : -1 pour auto, sinon fixe
            int userDefinedK = -1;

            SimpleKMeans kmeans;
            if (userDefinedK >= 2) {
                kmeans = new SimpleKMeans();
                kmeans.setNumClusters(userDefinedK);
                kmeans.setPreserveInstancesOrder(true);
                kmeans.buildClusterer(data);
                System.out.println("✔️ Utilisation du nombre de clusters défini par l'utilisateur : " + userDefinedK);
            } else {
                kmeans = KMeansTuner.findBestKMeans(data, 2, 8);
                System.out.println("🔎 Nombre de clusters optimal déterminé automatiquement : " + kmeans.getNumClusters());
            }

            // === Évaluation ===
            double silhouette = ClusterModelEvaluator.silhouetteScore(kmeans, data);
            double compactness = ClusterModelEvaluator.compactnessScore(kmeans, data);

            // === Taille du plus petit cluster ===
            int[] clusterSizes = new int[kmeans.getNumClusters()];
            int[] assignments = kmeans.getAssignments();
            for (int a : assignments) clusterSizes[a]++;
            int minClusterSize = Integer.MAX_VALUE;
            for (int size : clusterSizes) minClusterSize = Math.min(minClusterSize, size);

            // === Génération du rapport PDF ===
            PdfReportGenerator.generateReport(
                "rapport_kmeans_final.pdf",
                datasetName,
                -1.0, -1.0, 0, List.of(), // Aucune donnée DBSCAN
                silhouette,
                compactness,
                data.numInstances(),
                minClusterSize
            );

            // === Sauvegarde du modèle KMeans ===
            String modelPath = "src/main/resources/saved_models/kmeans.model";
            ModelUtils.saveModel(kmeans, modelPath);

            System.out.println("\n✅ Rapport KMeans généré avec succès.");
            System.out.println("✅ Modèle sauvegardé : " + modelPath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
