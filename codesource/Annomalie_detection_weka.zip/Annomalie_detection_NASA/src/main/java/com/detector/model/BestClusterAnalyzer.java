package com.detector.model;

import java.util.*;

public class BestClusterAnalyzer {
    public static int recommendBestK(Map<Integer, Double> sseScores,
                                     Map<Integer, Double> silhouetteScores,
                                     Map<Integer, int[]> clusterBalances) {

        double bestSilhouette = Double.NEGATIVE_INFINITY;
        int bestK = -1;

        for (Integer k : silhouetteScores.keySet()) {
            double silhouette = silhouetteScores.get(k);
            double balanceScore = computeBalanceScore(clusterBalances.get(k));
            double sse = sseScores.get(k);

            // Ici, on maximise un score combiné (simple pondération)
            double score = (0.5 * silhouette) + (0.3 * balanceScore) - (0.2 * normalizeSSE(sse));

            if (score > bestSilhouette) {
                bestSilhouette = score;
                bestK = k;
            }
        }
        return bestK;
    }

    private static double computeBalanceScore(int[] counts) {
        int total = Arrays.stream(counts).sum();
        double mean = total / (double) counts.length;
        double variance = 0;
        for (int c : counts) variance += Math.pow(c - mean, 2);
        return 1.0 / (1.0 + variance); // plus variance faible, meilleur équilibre
    }

    private static double normalizeSSE(double sse) {
        return Math.log(1 + sse); // Normalisation logarithmique simple
    }
}
