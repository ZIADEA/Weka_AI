package com.detector.model;

import weka.clusterers.Clusterer;
import weka.core.Instance;
import weka.core.Instances;

public class ClusterModelEvaluator {

    public static double silhouetteScore(Clusterer model, Instances data) throws Exception {
        int[] assignments = new int[data.numInstances()];
        int numClusters = 0;

        for (int i = 0; i < data.numInstances(); i++) {
            int cluster = model.clusterInstance(data.instance(i));
            assignments[i] = cluster;
            if (cluster >= numClusters) numClusters = cluster + 1;
        }

        if (numClusters < 2) return Double.NEGATIVE_INFINITY;

        double totalSilhouette = 0;
        for (int i = 0; i < data.numInstances(); i++) {
            Instance instA = data.instance(i);
            int clusterA = assignments[i];
            if (clusterA == -1) continue;

            double a = 0, b = Double.MAX_VALUE;
            int countA = 0;

            for (int j = 0; j < data.numInstances(); j++) {
                if (i == j) continue;
                Instance instB = data.instance(j);
                int clusterB = assignments[j];

                double dist = distance(instA, instB);

                if (clusterB == clusterA) {
                    a += dist;
                    countA++;
                } else if (clusterB != -1) {
                    b = Math.min(b, dist);
                }
            }

            if (countA > 0) a /= countA;
            totalSilhouette += (b - a) / Math.max(a, b);
        }

        return totalSilhouette / data.numInstances();
    }

    public static double compactnessScore(Clusterer model, Instances data) throws Exception {
        int[] assignments = new int[data.numInstances()];
        int numClusters = 0;
        double[][] clusterSums = new double[100][data.numAttributes()];
        int[] clusterCounts = new int[100];

        for (int i = 0; i < data.numInstances(); i++) {
            int cluster = model.clusterInstance(data.instance(i));
            assignments[i] = cluster;
            if (cluster >= numClusters) numClusters = cluster + 1;
            for (int j = 0; j < data.numAttributes(); j++) {
                clusterSums[cluster][j] += data.instance(i).value(j);
            }
            clusterCounts[cluster]++;
        }

        double totalVariance = 0;
        for (int i = 0; i < data.numInstances(); i++) {
            int cluster = assignments[i];
            for (int j = 0; j < data.numAttributes(); j++) {
                double mean = clusterSums[cluster][j] / clusterCounts[cluster];
                totalVariance += Math.pow(data.instance(i).value(j) - mean, 2);
            }
        }

        return totalVariance / data.numInstances();
    }

    private static double distance(Instance a, Instance b) {
        double sum = 0;
        for (int i = 0; i < a.numAttributes(); i++) {
            sum += Math.pow(a.value(i) - b.value(i), 2);
        }
        return Math.sqrt(sum);
    }
}
