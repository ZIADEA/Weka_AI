package com.detector.model;

import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import java.util.*;

public class WekaElbowEvaluator {
    public static Map<Integer, Double> evaluateSSE(Instances data, int kMin, int kMax) throws Exception {
        Map<Integer, Double> results = new LinkedHashMap<>();
        for (int k = kMin; k <= kMax; k++) {
            SimpleKMeans km = new SimpleKMeans();
            km.setNumClusters(k);
            km.setSeed(42);
            km.setPreserveInstancesOrder(true);
            km.buildClusterer(data);
            results.put(k, km.getSquaredError());
        }
        return results;
    }
}