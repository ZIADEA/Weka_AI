package com.detector.model;

import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import weka.core.Instance;

import java.util.*;

public class SilhouetteScoreEvaluator {
    public static Map<Integer, Double> evaluateSilhouette(Instances data, int kMin, int kMax) throws Exception {
        Map<Integer, Double> silhouetteScores = new LinkedHashMap<>();

        for (int k = kMin; k <= kMax; k++) {
            SimpleKMeans km = new SimpleKMeans();
            km.setNumClusters(k);
            km.setPreserveInstancesOrder(true);
            km.buildClusterer(data);
            int[] assignments = km.getAssignments();
            Instances centroids = km.getClusterCentroids();

            double totalSilhouette = 0;
            for (int i = 0; i < data.numInstances(); i++) {
                Instance instance = data.instance(i);
                int clusterIdx = assignments[i];
                double a = distance(instance, centroids.instance(clusterIdx));
                double b = Double.MAX_VALUE;
                for (int j = 0; j < centroids.numInstances(); j++) {
                    if (j != clusterIdx) {
                        double dist = distance(instance, centroids.instance(j));
                        if (dist < b) b = dist;
                    }
                }
                double s = (b - a) / Math.max(a, b);
                totalSilhouette += s;
            }
            silhouetteScores.put(k, totalSilhouette / data.numInstances());
        }
        return silhouetteScores;
    }

    private static double distance(Instance a, Instance b) {
        double sum = 0;
        for (int i = 0; i < a.numAttributes(); i++) {
            sum += Math.pow(a.value(i) - b.value(i), 2);
        }
        return Math.sqrt(sum);
    }
}
