package com.detector.utils;

import weka.clusterers.Clusterer;
import weka.core.SerializationHelper;

public class ModelUtils {

    public static void saveModel(Clusterer model, String path) throws Exception {
        SerializationHelper.write(path, model);
        System.out.println("✅ Modèle sauvegardé avec succès : " + path);
    }

    public static Clusterer loadModel(String path) throws Exception {
        System.out.println("🔁 Chargement du modèle depuis : " + path);
        return (Clusterer) SerializationHelper.read(path);
    }
} 
