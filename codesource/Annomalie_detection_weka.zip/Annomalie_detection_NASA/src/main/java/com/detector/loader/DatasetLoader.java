package com.detector.loader;

import weka.core.Instances;
import weka.core.Attribute;
import weka.core.converters.ConverterUtils.DataSource;

public class DatasetLoader {
    public static void main(String[] args) throws Exception {
        // Charger le dataset
        DataSource source = new DataSource("src/main/resources/bearing_data1.arff");
        Instances data = source.getDataSet();

        // Définir l'attribut de classe
        if (data.classIndex() == -1)
            data.setClassIndex(data.numAttributes() - 1);

        // Nombre d'instances
        System.out.println("Nombre d'instances : " + data.numInstances());

        // Nombre d'attributs
        System.out.println("Nombre d'attributs : " + data.numAttributes());

        // Afficher les attributs et leur type
        System.out.println("\n=== Liste des attributs ===");
        for (int i = 0; i < data.numAttributes(); i++) {
            Attribute attr = data.attribute(i);
            System.out.print((i + 1) + " - " + attr.name() + " (");

            switch (attr.type()) {
                case Attribute.NOMINAL:
                    System.out.print("Nominal - Valeurs possibles : " + attr.enumerateValues());
                    break;
                case Attribute.NUMERIC:
                    System.out.print("Numérique");
                    break;
                case Attribute.STRING:
                    System.out.print("String");
                    break;
                case Attribute.DATE:
                    System.out.print("Date");
                    break;
                default:
                    System.out.print("Inconnu");
            }
            System.out.println(")");
        }

        // Afficher un résumé du dataset
        System.out.println("\n=== Résumé du dataset ===");
        System.out.println(data.toSummaryString());
    }


}
