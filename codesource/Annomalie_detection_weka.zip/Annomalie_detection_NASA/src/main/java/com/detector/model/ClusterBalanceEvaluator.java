package com.detector.model;

import weka.clusterers.SimpleKMeans;
import weka.core.Instances;

import java.util.HashMap;
import java.util.Map;

public class ClusterBalanceEvaluator {
    public static Map<Integer, int[]> evaluateBalance(Instances data, int kMin, int kMax) throws Exception {
        Map<Integer, int[]> result = new HashMap<>();
        for (int k = kMin; k <= kMax; k++) {
            SimpleKMeans km = new SimpleKMeans();
            km.setNumClusters(k);
            km.setPreserveInstancesOrder(true);
            km.buildClusterer(data);

            int[] clusterCounts = new int[k];
            int[] assignments = km.getAssignments();
            for (int cluster : assignments) {
                clusterCounts[cluster]++;
            }
            result.put(k, clusterCounts);
        }
        return result;
    }
}
